

function getPageLanguage() {
  return window.location.pathname.includes('/en/') ? 'en' : 'es';
}

jQuery(document).ready(function () {

});